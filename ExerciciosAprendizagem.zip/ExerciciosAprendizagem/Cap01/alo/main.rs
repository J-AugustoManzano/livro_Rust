fn main() {
    println!("Alô, Mundo!");
}
